﻿from flask import Blueprint, render_template, request
from flask_login import login_required
import sqlite3

from translations import DEFAULT_LANG, SUPPORTED_LANGS
import translations_medicine  # adds the medicine page texts

medicines_bp = Blueprint("medicines", __name__)

MED_ANIMALS = ["Cow", "Goat", "Chicken", "Dog", "Cat", "Pigeon", "Fish", "Rabbit"]


def _lang():
    lang = request.cookies.get("lang", DEFAULT_LANG)
    return lang if lang in SUPPORTED_LANGS else DEFAULT_LANG


@medicines_bp.route("/medicines")
@login_required
def medicines_page():

    bn = _lang() == "bn"

    conn = sqlite3.connect("database/smartvet.db")
    conn.row_factory = sqlite3.Row
    rows = conn.execute("""
        SELECT * FROM medicines
        ORDER BY CASE access WHEN 'vet' THEN 1 WHEN 'general' THEN 2 ELSE 3 END, name_en
    """).fetchall()
    conn.close()

    items = []
    for r in rows:
        items.append({
            "name": (r["name_bn"] if bn else r["name_en"]) or r["name_en"],
            "search": ((r["name_en"] or "") + " " + (r["name_bn"] or "")).lower(),
            "category": (r["category_bn"] if bn else r["category_en"]) or "",
            "access": r["access"],
            "animals": [a for a in (r["animals"] or "").split(",") if a],
            "uses": (r["uses_bn"] if bn else r["uses_en"]) or "",
            "caution": (r["caution_bn"] if bn else r["caution_en"]) or "",
            "withdrawal": (r["withdrawal_bn"] if bn else r["withdrawal_en"]) or "",
        })

    return render_template("medicines.html", medicines=items, animals=MED_ANIMALS)
