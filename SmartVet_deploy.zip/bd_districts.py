﻿# 64 districts of Bangladesh: (English name used as the key, Bangla name)
DISTRICTS = [
    # Barishal
    ("Barguna", "বরগুনা"), ("Barishal", "বরিশাল"), ("Bhola", "ভোলা"),
    ("Jhalokathi", "ঝালকাঠি"), ("Patuakhali", "পটুয়াখালী"), ("Pirojpur", "পিরোজপুর"),
    # Chattogram
    ("Bandarban", "বান্দরবান"), ("Brahmanbaria", "ব্রাহ্মণবাড়িয়া"), ("Chandpur", "চাঁদপুর"),
    ("Chattogram", "চট্টগ্রাম"), ("Cumilla", "কুমিল্লা"), ("Cox's Bazar", "কক্সবাজার"),
    ("Feni", "ফেনী"), ("Khagrachhari", "খাগড়াছড়ি"), ("Lakshmipur", "লক্ষ্মীপুর"),
    ("Noakhali", "নোয়াখালী"), ("Rangamati", "রাঙ্গামাটি"),
    # Dhaka
    ("Dhaka", "ঢাকা"), ("Faridpur", "ফরিদপুর"), ("Gazipur", "গাজীপুর"),
    ("Gopalganj", "গোপালগঞ্জ"), ("Kishoreganj", "কিশোরগঞ্জ"), ("Madaripur", "মাদারীপুর"),
    ("Manikganj", "মানিকগঞ্জ"), ("Munshiganj", "মুন্সিগঞ্জ"), ("Narayanganj", "নারায়ণগঞ্জ"),
    ("Narsingdi", "নরসিংদী"), ("Rajbari", "রাজবাড়ী"), ("Shariatpur", "শরীয়তপুর"),
    ("Tangail", "টাঙ্গাইল"),
    # Khulna
    ("Bagerhat", "বাগেরহাট"), ("Chuadanga", "চুয়াডাঙ্গা"), ("Jashore", "যশোর"),
    ("Jhenaidah", "ঝিনাইদহ"), ("Khulna", "খুলনা"), ("Kushtia", "কুষ্টিয়া"),
    ("Magura", "মাগুরা"), ("Meherpur", "মেহেরপুর"), ("Narail", "নড়াইল"),
    ("Satkhira", "সাতক্ষীরা"),
    # Mymensingh
    ("Jamalpur", "জামালপুর"), ("Mymensingh", "ময়মনসিংহ"), ("Netrokona", "নেত্রকোনা"),
    ("Sherpur", "শেরপুর"),
    # Rajshahi
    ("Bogura", "বগুড়া"), ("Joypurhat", "জয়পুরহাট"), ("Naogaon", "নওগাঁ"),
    ("Natore", "নাটোর"), ("Chapainawabganj", "চাঁপাইনবাবগঞ্জ"), ("Pabna", "পাবনা"),
    ("Rajshahi", "রাজশাহী"), ("Sirajganj", "সিরাজগঞ্জ"),
    # Rangpur
    ("Dinajpur", "দিনাজপুর"), ("Gaibandha", "গাইবান্ধা"), ("Kurigram", "কুড়িগ্রাম"),
    ("Lalmonirhat", "লালমনিরহাট"), ("Nilphamari", "নীলফামারী"), ("Panchagarh", "পঞ্চগড়"),
    ("Rangpur", "রংপুর"), ("Thakurgaon", "ঠাকুরগাঁও"),
    # Sylhet
    ("Habiganj", "হবিগঞ্জ"), ("Moulvibazar", "মৌলভীবাজার"), ("Sunamganj", "সুনামগঞ্জ"),
    ("Sylhet", "সিলেট"),
]

DISTRICT_BN = dict(DISTRICTS)

if __name__ == "__main__":
    print("Districts:", len(DISTRICTS))
    print("Duplicates:", len(DISTRICTS) - len(DISTRICT_BN))
