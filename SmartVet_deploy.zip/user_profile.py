﻿import re
import sqlite3
from datetime import datetime, timedelta

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash

from translations import DEFAULT_LANG, SUPPORTED_LANGS, get_text
from bd_districts import DISTRICTS, DISTRICT_BN
import translations_profile  # adds the profile page texts

profile_bp = Blueprint("profile", __name__)

USER_TYPES = [
    "Farmer", "SmallFarmer", "LargeFarmer", "PoultryOwner", "DairyFarm",
    "PetOwner", "VetStudent", "LivestockWorker", "NGO",
]
BN_DIGITS = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")
PHONE_OK = re.compile(r"^[0-9+\-\s()]{6,20}$")
NO_MATCH_VALUES = ("NO_MATCH", "কোনো মিল পাওয়া যায়নি")
OPTIONAL_FIELDS = ("phone", "district", "address", "user_type", "farm_name")


def _lang():
    lang = request.cookies.get("lang", DEFAULT_LANG)
    return lang if lang in SUPPORTED_LANGS else DEFAULT_LANG


def _tr(key):
    return get_text(_lang(), key)


def _connect():
    conn = sqlite3.connect("database/smartvet.db")
    conn.row_factory = sqlite3.Row
    return conn


def _format_date(value):
    """Database time is UTC; show it in Bangladesh time (UTC+6)."""
    try:
        dt = datetime.strptime(value, "%Y-%m-%d %H:%M:%S") + timedelta(hours=6)
        return dt.strftime("%d %b %Y, %I:%M %p")
    except Exception:
        return value or ""


def _district_options():
    bn = _lang() == "bn"
    options = [(en, bn_name if bn else en) for en, bn_name in DISTRICTS]
    options.sort(key=lambda x: x[1])
    return options


@profile_bp.route("/profile")
@login_required
def profile_page():

    lang = _lang()

    conn = _connect()
    row = conn.execute("""
        SELECT id, name, email, role, phone, district, address, user_type, farm_name
        FROM users WHERE id = ?
    """, (current_user.id,)).fetchone()

    if row is None:
        conn.close()
        abort(404)

    count = conn.execute(
        "SELECT COUNT(*) FROM history WHERE user_id = ?", (current_user.id,)
    ).fetchone()[0]

    last = conn.execute("""
        SELECT animal, disease, search_date FROM history
        WHERE user_id = ? ORDER BY search_date DESC, id DESC LIMIT 1
    """, (current_user.id,)).fetchone()

    bn_names = {
        r["disease_name"]: r["disease_name_bn"]
        for r in conn.execute("SELECT disease_name, disease_name_bn FROM diseases")
        if r["disease_name_bn"]
    }
    conn.close()

    p = dict(row)

    filled = sum(1 for k in OPTIONAL_FIELDS if p.get(k) and str(p[k]).strip())
    percent = round((2 + filled) / (2 + len(OPTIONAL_FIELDS)) * 100)

    last_info = None
    if last:
        if last["disease"] in NO_MATCH_VALUES:
            disease_text = get_text(lang, "hist_no_match")
        elif lang == "bn":
            disease_text = bn_names.get(last["disease"], last["disease"])
        else:
            disease_text = last["disease"]

        last_info = {
            "animal": get_text(lang, "animal_" + (last["animal"] or ""), last["animal"] or ""),
            "disease": disease_text,
            "date": _format_date(last["search_date"]),
        }

    return render_template(
        "profile.html",
        p=p,
        percent=percent,
        districts=_district_options(),
        user_types=USER_TYPES,
        total_checks=count,
        last_check=last_info,
    )


@profile_bp.route("/profile/update", methods=["POST"])
@login_required
def profile_update():

    name = request.form.get("name", "").strip()[:100]
    phone = request.form.get("phone", "").strip().translate(BN_DIGITS)
    district = request.form.get("district", "").strip()
    address = request.form.get("address", "").strip()[:200]
    user_type = request.form.get("user_type", "").strip()
    farm_name = request.form.get("farm_name", "").strip()[:150]

    back = url_for("profile.profile_page")

    if not name:
        flash(_tr("prof_flash_name"), "error")
        return redirect(back)
    if phone and not PHONE_OK.match(phone):
        flash(_tr("prof_flash_phone"), "error")
        return redirect(back)
    if district and district not in DISTRICT_BN:
        flash(_tr("prof_flash_district"), "error")
        return redirect(back)
    if user_type and user_type not in USER_TYPES:
        flash(_tr("prof_flash_type"), "error")
        return redirect(back)

    conn = _connect()
    conn.execute("""
        UPDATE users
        SET name = ?, phone = ?, district = ?, address = ?, user_type = ?, farm_name = ?
        WHERE id = ?
    """, (name, phone, district, address, user_type, farm_name, current_user.id))
    conn.commit()
    conn.close()

    flash(_tr("prof_flash_saved"), "success")
    return redirect(back)


@profile_bp.route("/profile/password", methods=["POST"])
@login_required
def profile_password():

    current = request.form.get("current_password", "")
    new = request.form.get("new_password", "")
    confirm = request.form.get("confirm_password", "")

    back = url_for("profile.profile_page") + "#password"

    conn = _connect()
    row = conn.execute("SELECT password FROM users WHERE id = ?", (current_user.id,)).fetchone()

    if row is None or not check_password_hash(row["password"], current):
        conn.close()
        flash(_tr("prof_flash_pw_wrong"), "error")
        return redirect(back)

    if len(new) < 6:
        conn.close()
        flash(_tr("prof_flash_pw_short"), "error")
        return redirect(back)

    if new != confirm:
        conn.close()
        flash(_tr("prof_flash_pw_mismatch"), "error")
        return redirect(back)

    if check_password_hash(row["password"], new):
        conn.close()
        flash(_tr("prof_flash_pw_same"), "error")
        return redirect(back)

    conn.execute(
        "UPDATE users SET password = ? WHERE id = ?",
        (generate_password_hash(new), current_user.id),
    )
    conn.commit()
    conn.close()

    flash(_tr("prof_flash_pw_ok"), "success")
    return redirect(back)
