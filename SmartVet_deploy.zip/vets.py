﻿import re
import sqlite3
from functools import wraps

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user

from translations import DEFAULT_LANG, SUPPORTED_LANGS, get_text
from bd_districts import DISTRICTS, DISTRICT_BN
import translations_vets  # adds the vet directory texts

vets_bp = Blueprint("vets", __name__)

VET_ANIMALS = ["Cow", "Goat", "Chicken", "Dog", "Cat", "Pigeon", "Fish", "Rabbit"]
BN_DIGITS = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")
PHONE_OK = re.compile(r"^[0-9+\-\s()]{6,20}$")


def _lang():
    lang = request.cookies.get("lang", DEFAULT_LANG)
    return lang if lang in SUPPORTED_LANGS else DEFAULT_LANG


def _tr(key):
    return get_text(_lang(), key)


def admin_only(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return decorated


def _connect():
    conn = sqlite3.connect("database/smartvet.db")
    conn.row_factory = sqlite3.Row
    return conn


def _district_options():
    bn = _lang() == "bn"
    options = [(en, bn_name if bn else en) for en, bn_name in DISTRICTS]
    options.sort(key=lambda x: x[1])
    return options


def _row_to_vet(row):
    bn = _lang() == "bn"
    district_en = row["district"]
    phone = row["phone"] or ""
    return {
        "id": row["id"],
        "name": row["name"],
        "qualification": row["qualification"] or "",
        "clinic": row["clinic"] or "",
        "district": DISTRICT_BN.get(district_en, district_en) if bn else district_en,
        "district_key": district_en,
        "address": row["address"] or "",
        "phone": phone,
        "tel": re.sub(r"[^0-9+]", "", phone),
        "hours": row["hours"] or "",
        "animals": [a for a in (row["animals"] or "").split(",") if a],
        "emergency": bool(row["emergency_24h"]),
    }


# -----------------------------
# Public page
# -----------------------------

@vets_bp.route("/vets")
@login_required
def vets_page():

    district = request.args.get("district", "").strip()
    animal = request.args.get("animal", "").strip()
    q = request.args.get("q", "").strip()

    conn = _connect()
    rows = conn.execute("SELECT * FROM vets ORDER BY emergency_24h DESC, name").fetchall()
    conn.close()

    all_vets = [_row_to_vet(r) for r in rows]
    vets = all_vets

    if district in DISTRICT_BN:
        vets = [v for v in vets if v["district_key"] == district]
    if animal in VET_ANIMALS:
        vets = [v for v in vets if animal in v["animals"]]
    if q:
        ql = q.lower()
        vets = [v for v in vets if ql in (v["name"] + " " + v["clinic"] + " " + v["address"]).lower()]

    return render_template(
        "vets.html",
        vets=vets,
        total=len(all_vets),
        districts=_district_options(),
        animals=VET_ANIMALS,
        sel_district=district,
        sel_animal=animal,
        q=q,
    )


# -----------------------------
# Admin: manage vets
# -----------------------------

@vets_bp.route("/admin/vets")
@login_required
@admin_only
def admin_vets_page():

    edit_id = request.args.get("edit", type=int)

    conn = _connect()
    rows = conn.execute("SELECT * FROM vets ORDER BY name").fetchall()

    edit_vet = None
    if edit_id:
        r = conn.execute("SELECT * FROM vets WHERE id = ?", (edit_id,)).fetchone()
        if r:
            edit_vet = dict(r)
            edit_vet["animals"] = [a for a in (r["animals"] or "").split(",") if a]
    conn.close()

    return render_template(
        "admin_vets.html",
        vets=[_row_to_vet(r) for r in rows],
        edit_vet=edit_vet,
        districts=_district_options(),
        animals=VET_ANIMALS,
    )


@vets_bp.route("/admin/vets/save", methods=["POST"])
@login_required
@admin_only
def admin_vets_save():

    vet_id = request.form.get("id", type=int)

    name = request.form.get("name", "").strip()[:100]
    qualification = request.form.get("qualification", "").strip()[:100]
    clinic = request.form.get("clinic", "").strip()[:150]
    district = request.form.get("district", "").strip()
    address = request.form.get("address", "").strip()[:200]
    phone = request.form.get("phone", "").strip().translate(BN_DIGITS)
    hours = request.form.get("hours", "").strip()[:100]
    animals = [a for a in request.form.getlist("animals") if a in VET_ANIMALS]
    emergency = 1 if request.form.get("emergency_24h") else 0

    back = url_for("vets.admin_vets_page", edit=vet_id) if vet_id else url_for("vets.admin_vets_page")

    if not name:
        flash(_tr("av_flash_invalid_name"))
        return redirect(back)
    if district not in DISTRICT_BN:
        flash(_tr("av_flash_invalid_district"))
        return redirect(back)
    if not PHONE_OK.match(phone):
        flash(_tr("av_flash_invalid_phone"))
        return redirect(back)

    conn = _connect()
    cursor = conn.cursor()

    if vet_id:
        cursor.execute("""
            UPDATE vets
            SET name = ?, qualification = ?, clinic = ?, district = ?, address = ?,
                phone = ?, hours = ?, animals = ?, emergency_24h = ?
            WHERE id = ?
        """, (name, qualification, clinic, district, address, phone, hours,
              ",".join(animals), emergency, vet_id))
        if cursor.rowcount == 0:
            conn.close()
            flash(_tr("av_flash_not_found"))
            return redirect(url_for("vets.admin_vets_page"))
        flash(_tr("av_flash_updated"))
    else:
        cursor.execute("""
            INSERT INTO vets
            (name, qualification, clinic, district, address, phone, hours, animals, emergency_24h)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (name, qualification, clinic, district, address, phone, hours,
              ",".join(animals), emergency))
        flash(_tr("av_flash_saved"))

    conn.commit()
    conn.close()

    return redirect(url_for("vets.admin_vets_page"))


@vets_bp.route("/admin/vets/delete/<int:vet_id>", methods=["POST"])
@login_required
@admin_only
def admin_vets_delete(vet_id):

    conn = _connect()
    conn.execute("DELETE FROM vets WHERE id = ?", (vet_id,))
    conn.commit()
    conn.close()

    flash(_tr("av_flash_deleted"))
    return redirect(url_for("vets.admin_vets_page"))
