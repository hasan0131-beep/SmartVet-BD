﻿from translations import TRANSLATIONS

TRANSLATIONS["bn"].update({
    "nav_medicines": "ওষুধ",
    "med_page_title": "ওষুধের তথ্য - SmartVet",
    "med_title": "ওষুধের তথ্য লাইব্রেরি",
    "med_intro": "প্রাণীর সাধারণ ওষুধ সম্পর্কে প্রাথমিক তথ্য এখানে পাবেন।",
    "med_warning": "এখানে ইচ্ছাকৃতভাবে কোনো ডোজ বা পরিমাণ দেওয়া হয়নি। ভুল ডোজে প্রাণী মারা যেতে পারে, আর অ্যান্টিবায়োটিকের ভুল ব্যবহারে জীবাণু ওষুধ-প্রতিরোধী হয়ে যায়। কোনো ওষুধ দেওয়ার আগে অবশ্যই পশুচিকিৎসকের পরামর্শ নিন।",
    "med_search_ph": "ওষুধের নাম খুঁজুন...",
    "med_filter_animal": "প্রাণী",
    "med_filter_type": "ধরন",
    "med_filter_all": "সব",
    "med_access_vet": "পশুচিকিৎসকের পরামর্শে",
    "med_access_general": "সাধারণ সহায়ক",
    "med_access_avoid": "প্রাণীকে দেবেন না",
    "med_uses": "কীসের জন্য",
    "med_caution": "সতর্কতা",
    "med_withdrawal": "দুধ, মাংস ও ডিম সম্পর্কে",
    "med_for_animals": "যেসব প্রাণীর জন্য",
    "med_no_results": "কোনো ওষুধ পাওয়া যায়নি।",
    "feat_med_title": "ওষুধের তথ্য",
    "feat_med_desc": "সাধারণ ওষুধের ব্যবহার ও সতর্কতা জানুন।",
})

TRANSLATIONS["en"].update({
    "nav_medicines": "Medicines",
    "med_page_title": "Medicine Information - SmartVet",
    "med_title": "Medicine Information Library",
    "med_intro": "Find basic information about common animal medicines here.",
    "med_warning": "No doses or amounts are given here on purpose. A wrong dose can kill an animal, and misusing antibiotics makes germs resistant to medicine. Always consult a veterinarian before giving any medicine.",
    "med_search_ph": "Search by medicine name...",
    "med_filter_animal": "Animal",
    "med_filter_type": "Type",
    "med_filter_all": "All",
    "med_access_vet": "Only with a vet's advice",
    "med_access_general": "General support",
    "med_access_avoid": "Do not give to animals",
    "med_uses": "What it is used for",
    "med_caution": "Cautions",
    "med_withdrawal": "Milk, meat and eggs",
    "med_for_animals": "For these animals",
    "med_no_results": "No medicine found.",
    "feat_med_title": "Medicine Info",
    "feat_med_desc": "Learn about common medicines and their cautions.",
})

if __name__ == "__main__":
    print("bn keys:", len(TRANSLATIONS["bn"]), "en keys:", len(TRANSLATIONS["en"]))
    print("Missing in en:", sorted(set(TRANSLATIONS["bn"]) - set(TRANSLATIONS["en"])) or "none")
    print("Missing in bn:", sorted(set(TRANSLATIONS["en"]) - set(TRANSLATIONS["bn"])) or "none")
