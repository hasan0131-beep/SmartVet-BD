from flask import (Flask, render_template, request, jsonify, redirect, url_for,
                   flash, abort, make_response)
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime, timedelta
from urllib.parse import urlparse
import sqlite3
import os
import secrets
from flask_wtf.csrf import CSRFProtect, CSRFError
from groq import Groq
from dotenv import load_dotenv

from translations import (
    DEFAULT_LANG, SUPPORTED_LANGS, AI_INSTRUCTIONS, get_text, js_strings
)

from medicines import medicines_bp
from vets import vets_bp
from user_profile import profile_bp

load_dotenv()

app = Flask(__name__)
app.register_blueprint(medicines_bp)
app.register_blueprint(vets_bp)
app.register_blueprint(profile_bp)
# -----------------------------
# Security settings
# -----------------------------

_secret = os.getenv("SECRET_KEY")
if not _secret:
    print("WARNING: SECRET_KEY is not set in .env. Using a temporary random key.")
    _secret = secrets.token_hex(32)
app.secret_key = _secret

app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=(os.getenv("COOKIE_SECURE") == "1"),
    REMEMBER_COOKIE_HTTPONLY=True,
    REMEMBER_COOKIE_SAMESITE="Lax",
    MAX_CONTENT_LENGTH=8 * 1024 * 1024,
    WTF_CSRF_TIME_LIMIT=None,
)

csrf = CSRFProtect(app)


@app.errorhandler(CSRFError)
def handle_csrf_error(e):
    if get_lang() == "bn":
        msg = "নিরাপত্তা যাচাই ব্যর্থ হয়েছে। পেজটা রিফ্রেশ করে আবার চেষ্টা করুন।"
    else:
        msg = "Security check failed. Please refresh the page and try again."

    if request.is_json or request.path in ("/search_disease", "/ai_chat_api"):
        return jsonify({"status": "error", "message": msg}), 400

    flash(msg, "error")
    return redirect(request.referrer or url_for("home"))


@app.after_request
def add_security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    return response


ANIMALS = ["Cow", "Goat", "Chicken", "Dog", "Cat", "Pigeon", "Fish", "Rabbit"]
SYMPTOMS = ["Fever", "Cough", "Loss of Appetite", "Diarrhea", "Skin Lesion", "Difficulty Breathing"]

# -----------------------------
# Groq AI Setup
# -----------------------------

groq_client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# -----------------------------
# Language (Bangla / English)
# -----------------------------

def get_lang():
    lang = request.cookies.get("lang", DEFAULT_LANG)
    if lang not in SUPPORTED_LANGS:
        lang = DEFAULT_LANG
    return lang


def tr(key):
    """Translate a key into the visitor's current language (for use inside Python code)."""
    return get_text(get_lang(), key)


@app.context_processor
def inject_i18n():
    lang = get_lang()
    return {
        "t": lambda key: get_text(lang, key),
        "lang": lang,
        "i18n_js": js_strings(lang),
    }


@app.route("/set_lang/<lang>")
def set_lang(lang):
    if lang not in SUPPORTED_LANGS:
        lang = DEFAULT_LANG

    target = url_for("home")
    ref = request.referrer
    if ref and urlparse(ref).netloc == request.host:
        target = ref

    resp = make_response(redirect(target))
    resp.set_cookie("lang", lang, max_age=60 * 60 * 24 * 365, samesite="Lax")
    return resp


def format_date(value):
    """Database time is UTC; show it in Bangladesh time (UTC+6)."""
    try:
        dt = datetime.strptime(value, "%Y-%m-%d %H:%M:%S") + timedelta(hours=6)
        return dt.strftime("%d %b %Y, %I:%M %p")
    except Exception:
        return value or ""

# -----------------------------
# Flask-Login Setup
# -----------------------------

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


class User(UserMixin):
    def __init__(self, id, name, email, role="user"):
        self.id = id
        self.name = name
        self.email = email
        self.role = role

    @property
    def is_admin(self):
        return self.role == "admin"


@login_manager.user_loader
def load_user(user_id):
    conn = sqlite3.connect("database/smartvet.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, email, role FROM users WHERE id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()

    if row:
        return User(row[0], row[1], row[2], row[3] or "user")
    return None


def admin_required(f):
    """Only admins may enter. Place it below @login_required."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return decorated


@app.errorhandler(403)
def forbidden(e):
    return tr("forbidden_msg"), 403


# -----------------------------
# Pages
# -----------------------------

@app.route("/")
def home():
    return render_template("index.html", animals=ANIMALS)


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", user_name=current_user.name, animals=ANIMALS)


@app.route("/animal/<animal_name>")
@login_required
def animal(animal_name):
    animal_name = animal_name.capitalize()
    if animal_name not in ANIMALS:
        abort(404)
    return render_template("animal.html", animal=animal_name, symptoms=SYMPTOMS)


@app.route("/ai-chat")
@login_required
def ai_chat_page():
    return render_template("ai_chat.html")


@app.route("/emergency")
@login_required
def emergency_page():
    return render_template("emergency.html")


@app.route("/history")
@login_required
def history_page():

    lang = get_lang()

    conn = sqlite3.connect("database/smartvet.db")
    cursor = conn.cursor()

    cursor.execute("""
        SELECT animal, symptoms, disease, search_date
        FROM history
        WHERE user_id = ?
        ORDER BY search_date DESC, id DESC
    """, (current_user.id,))
    rows = cursor.fetchall()

    cursor.execute("SELECT disease_name, disease_name_bn FROM diseases")
    bn_names = {en: bn for en, bn in cursor.fetchall() if bn}

    conn.close()

    records = []
    for animal_name, symptoms, disease, search_date in rows:

        symptom_list = [
            get_text(lang, "sym_" + s.strip(), s.strip())
            for s in (symptoms or "").split(",") if s.strip()
        ]

        if disease in ("NO_MATCH", "কোনো মিল পাওয়া যায়নি"):
            matched = False
            disease_text = get_text(lang, "hist_no_match")
        else:
            matched = True
            disease_text = bn_names.get(disease, disease) if lang == "bn" else disease

        records.append({
            "animal": get_text(lang, "animal_" + (animal_name or ""), animal_name or ""),
            "animal_key": animal_name,
            "symptoms": symptom_list,
            "disease": disease_text,
            "matched": matched,
            "date": format_date(search_date),
        })

    return render_template("history.html", records=records)


# -----------------------------
# Admin Panel
# -----------------------------

@app.route("/admin")
@login_required
@admin_required
def admin_page():

    conn = sqlite3.connect("database/smartvet.db")
    cursor = conn.cursor()

    cursor.execute("SELECT id, name, email, role FROM users ORDER BY id")
    users = cursor.fetchall()

    cursor.execute("SELECT COUNT(*) FROM history")
    history_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM diseases")
    disease_count = cursor.fetchone()[0]

    conn.close()

    return render_template(
        "admin.html",
        users=users,
        history_count=history_count,
        disease_count=disease_count
    )


@app.route("/admin/set_role/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def admin_set_role(user_id):

    new_role = request.form.get("role")

    if new_role not in ("user", "admin"):
        flash(tr("admin_flash_bad_role"))
        return redirect(url_for("admin_page"))

    if user_id == current_user.id:
        flash(tr("admin_flash_self_role"))
        return redirect(url_for("admin_page"))

    conn = sqlite3.connect("database/smartvet.db")
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET role = ? WHERE id = ?", (new_role, user_id))
    conn.commit()
    conn.close()

    flash(tr("admin_flash_role_ok"))
    return redirect(url_for("admin_page"))


@app.route("/admin/delete/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def admin_delete_user(user_id):

    if user_id == current_user.id:
        flash(tr("admin_flash_self_delete"))
        return redirect(url_for("admin_page"))

    conn = sqlite3.connect("database/smartvet.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM history WHERE user_id = ?", (user_id,))
    cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()

    flash(tr("admin_flash_deleted"))
    return redirect(url_for("admin_page"))


# -----------------------------
# Register
# -----------------------------

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "GET":
        return render_template("register.html")

    name = request.form.get("name")
    email = request.form.get("email")
    password = request.form.get("password")

    if not name or not email or not password:
        return render_template("register.html", error=tr("reg_error_empty"))

    hashed_password = generate_password_hash(password)

    conn = sqlite3.connect("database/smartvet.db")
    cursor = conn.cursor()

    try:
        cursor.execute(
            "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')",
            (name, email, hashed_password)
        )
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return render_template("register.html", error=tr("reg_error_exists"))

    conn.close()

    return redirect(url_for("login"))


# -----------------------------
# Login
# -----------------------------

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "GET":
        return render_template("login.html")

    email = request.form.get("email")
    password = request.form.get("password")

    conn = sqlite3.connect("database/smartvet.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, email, password, role FROM users WHERE email = ?", (email,))
    row = cursor.fetchone()
    conn.close()

    if row and check_password_hash(row[3], password):
        user = User(row[0], row[1], row[2], row[4] or "user")
        login_user(user)
        return redirect(url_for("dashboard"))

    return render_template("login.html", error=tr("login_error"))


# -----------------------------
# Logout
# -----------------------------

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("home"))


# -----------------------------
# Disease Search API
# -----------------------------

@app.route("/search_disease", methods=["POST"])
@login_required
def search_disease():

    data = request.get_json()

    if not data:
        return jsonify({
            "status": "error",
            "message": "No data received."
        })

    lang = get_lang()
    animal = data.get("animal")
    selected_symptoms = data.get("symptoms", [])

    conn = sqlite3.connect("database/smartvet.db")
    cursor = conn.cursor()

    cursor.execute("""
        SELECT disease_name, symptom, description, treatment,
               disease_name_bn, description_bn, treatment_bn
        FROM diseases
        WHERE animal = ?
    """, (animal,))

    diseases = cursor.fetchall()

    results = []

    for row in diseases:

        name_en, symptom_text, desc_en, treat_en, name_bn, desc_bn, treat_bn = row
        db_symptoms = [x.strip() for x in symptom_text.split(",")]

        matched = 0
        for symptom in selected_symptoms:
            if symptom in db_symptoms:
                matched += 1

        if matched > 0:

            percentage = round((matched / len(db_symptoms)) * 100)

            if lang == "bn":
                shown_name = name_bn or name_en
                shown_desc = desc_bn or desc_en
                shown_treat = treat_bn or treat_en
            else:
                shown_name = name_en
                shown_desc = desc_en
                shown_treat = treat_en

            results.append({
                "disease": shown_name,
                "disease_en": name_en,
                "description": shown_desc,
                "treatment": shown_treat,
                "match": percentage
            })

    results.sort(key=lambda x: x["match"], reverse=True)

    top_results = results[:3]

    if len(top_results) > 0:
        top_disease_name = top_results[0]["disease_en"]
    else:
        top_disease_name = "NO_MATCH"

    cursor.execute("""
        INSERT INTO history (user_id, animal, symptoms, disease)
        VALUES (?, ?, ?, ?)
    """, (current_user.id, animal, ", ".join(selected_symptoms), top_disease_name))

    conn.commit()
    conn.close()

    if len(top_results) == 0:
        return jsonify({
            "status": "not_found"
        })

    return jsonify({
        "status": "success",
        "results": top_results
    })


# -----------------------------
# AI Chat API
# -----------------------------

@app.route("/ai_chat_api", methods=["POST"])
@login_required
def ai_chat_api():

    data = request.get_json()

    if not data or not data.get("message"):
        return jsonify({
            "status": "error",
            "message": tr("ai_no_message")
        })

    user_message = data.get("message")
    instruction = AI_INSTRUCTIONS.get(get_lang(), AI_INSTRUCTIONS[DEFAULT_LANG])

    try:
        response = groq_client.chat.completions.create(
            model="openai/gpt-oss-20b",
            messages=[
                {"role": "system", "content": instruction},
                {"role": "user", "content": user_message}
            ]
        )
        reply_text = response.choices[0].message.content
    except Exception as e:
        print("GROQ ERROR:", e)
        return jsonify({
            "status": "error",
            "message": tr("ai_server_error")
        })

    return jsonify({
        "status": "success",
        "reply": reply_text
    })


# -----------------------------
# Run App
# -----------------------------

if __name__ == "__main__":
    app.run(debug=True)