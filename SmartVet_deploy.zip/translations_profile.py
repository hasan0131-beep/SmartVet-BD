﻿from translations import TRANSLATIONS

TRANSLATIONS["bn"].update({
    "nav_profile": "আমার প্রোফাইল",

    "prof_page_title": "আমার প্রোফাইল - SmartVet",
    "prof_title": "আমার প্রোফাইল",
    "prof_complete_label": "প্রোফাইল সম্পূর্ণ",
    "prof_complete_hint": "আরও তথ্য যোগ করে প্রোফাইল সম্পূর্ণ করুন।",
    "prof_privacy": "অন্য ইউজাররা আপনার এই তথ্য দেখতে পায় না।",

    "prof_personal_title": "ব্যক্তিগত তথ্য",
    "prof_name": "নাম",
    "prof_phone": "ফোন নম্বর",
    "prof_district": "জেলা",
    "prof_choose_district": "জেলা বেছে নিন",
    "prof_address": "ঠিকানা বা গ্রাম",
    "prof_user_type": "আপনি কে?",
    "prof_choose_type": "বেছে নিন",
    "prof_farm_name": "খামারের নাম",
    "prof_optional": "ঐচ্ছিক",
    "prof_save": "সংরক্ষণ করুন",

    "ut_Farmer": "কৃষক",
    "ut_SmallFarmer": "ছোট খামারি",
    "ut_LargeFarmer": "বড় খামারি",
    "ut_PoultryOwner": "পোল্ট্রি মালিক",
    "ut_DairyFarm": "ডেইরি ফার্ম মালিক",
    "ut_PetOwner": "পোষা প্রাণীর মালিক",
    "ut_VetStudent": "ভেটেরিনারি শিক্ষার্থী",
    "ut_LivestockWorker": "প্রাণিসম্পদ কর্মী",
    "ut_NGO": "এনজিও",

    "prof_account_title": "অ্যাকাউন্ট",
    "prof_email": "ইমেইল",
    "prof_email_note": "ইমেইল বদলানো যায় না।",
    "prof_role": "ভূমিকা",

    "prof_pw_title": "পাসওয়ার্ড পরিবর্তন",
    "prof_pw_current": "বর্তমান পাসওয়ার্ড",
    "prof_pw_new": "নতুন পাসওয়ার্ড",
    "prof_pw_confirm": "নতুন পাসওয়ার্ড আবার লিখুন",
    "prof_pw_hint": "কমপক্ষে ৬ অক্ষর",
    "prof_pw_btn": "পাসওয়ার্ড বদলান",

    "prof_activity_title": "আমার কার্যকলাপ",
    "prof_checks_total": "মোট রোগ পরীক্ষা",
    "prof_last_check": "সর্বশেষ পরীক্ষা",
    "prof_no_activity": "এখনো কোনো পরীক্ষা করা হয়নি।",
    "prof_view_history": "ইতিহাস দেখুন",

    "prof_flash_saved": "প্রোফাইল সংরক্ষণ করা হয়েছে।",
    "prof_flash_name": "নাম লিখুন।",
    "prof_flash_phone": "সঠিক ফোন নম্বর দিন (শুধু সংখ্যা, + ও - ব্যবহার করা যাবে)।",
    "prof_flash_district": "সঠিক জেলা বেছে নিন।",
    "prof_flash_type": "সঠিক ধরন বেছে নিন।",
    "prof_flash_pw_wrong": "বর্তমান পাসওয়ার্ড ভুল হয়েছে।",
    "prof_flash_pw_short": "নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।",
    "prof_flash_pw_mismatch": "নতুন পাসওয়ার্ড দুটো মেলেনি।",
    "prof_flash_pw_same": "নতুন পাসওয়ার্ড আগেরটার মতো হতে পারবে না।",
    "prof_flash_pw_ok": "পাসওয়ার্ড সফলভাবে বদলানো হয়েছে।",
})

TRANSLATIONS["en"].update({
    "nav_profile": "My Profile",

    "prof_page_title": "My Profile - SmartVet",
    "prof_title": "My Profile",
    "prof_complete_label": "Profile complete",
    "prof_complete_hint": "Add more details to complete your profile.",
    "prof_privacy": "Other users cannot see these details.",

    "prof_personal_title": "Personal Information",
    "prof_name": "Name",
    "prof_phone": "Phone number",
    "prof_district": "District",
    "prof_choose_district": "Choose a district",
    "prof_address": "Address or village",
    "prof_user_type": "I am a...",
    "prof_choose_type": "Choose one",
    "prof_farm_name": "Farm name",
    "prof_optional": "optional",
    "prof_save": "Save changes",

    "ut_Farmer": "Farmer",
    "ut_SmallFarmer": "Small-scale farmer",
    "ut_LargeFarmer": "Large-scale farmer",
    "ut_PoultryOwner": "Poultry owner",
    "ut_DairyFarm": "Dairy farm owner",
    "ut_PetOwner": "Pet owner",
    "ut_VetStudent": "Veterinary student",
    "ut_LivestockWorker": "Livestock worker",
    "ut_NGO": "NGO",

    "prof_account_title": "Account",
    "prof_email": "Email",
    "prof_email_note": "Email cannot be changed.",
    "prof_role": "Role",

    "prof_pw_title": "Change Password",
    "prof_pw_current": "Current password",
    "prof_pw_new": "New password",
    "prof_pw_confirm": "Confirm new password",
    "prof_pw_hint": "At least 6 characters",
    "prof_pw_btn": "Change password",

    "prof_activity_title": "My Activity",
    "prof_checks_total": "Total disease checks",
    "prof_last_check": "Last check",
    "prof_no_activity": "You have not made any checks yet.",
    "prof_view_history": "View history",

    "prof_flash_saved": "Profile saved.",
    "prof_flash_name": "Please enter your name.",
    "prof_flash_phone": "Please enter a valid phone number (digits, + and - only).",
    "prof_flash_district": "Please choose a valid district.",
    "prof_flash_type": "Please choose a valid type.",
    "prof_flash_pw_wrong": "Your current password is incorrect.",
    "prof_flash_pw_short": "The new password must be at least 6 characters long.",
    "prof_flash_pw_mismatch": "The two new passwords do not match.",
    "prof_flash_pw_same": "The new password cannot be the same as the old one.",
    "prof_flash_pw_ok": "Password changed successfully.",
})

if __name__ == "__main__":
    print("bn keys:", len(TRANSLATIONS["bn"]), "en keys:", len(TRANSLATIONS["en"]))
    print("Missing in en:", sorted(set(TRANSLATIONS["bn"]) - set(TRANSLATIONS["en"])) or "none")
    print("Missing in bn:", sorted(set(TRANSLATIONS["en"]) - set(TRANSLATIONS["bn"])) or "none")
