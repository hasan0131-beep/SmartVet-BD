﻿DEFAULT_LANG = "bn"
SUPPORTED_LANGS = ("bn", "en")

TRANSLATIONS = {

    "bn": {
        # ---- Navbar ----
        "nav_home": "হোম",
        "nav_dashboard": "ড্যাশবোর্ড",
        "nav_ai": "AI সহায়ক",
        "nav_admin": "অ্যাডমিন",
        "nav_history": "ইতিহাস",
        "nav_login": "লগইন",
        "nav_register": "রেজিস্টার",
        "nav_logout": "লগআউট",
        "lang_switch_label": "English",
        "lang_switch_title": "Switch to English",

        # ---- Common ----
        "back_dashboard": "ড্যাশবোর্ডে ফিরুন",
        "site_footer": "© 2026 SmartVet BD — সঠিক তথ্য, সুস্থ প্রাণী, সমৃদ্ধ খামার।",
        "site_disclaimer": "এই সাইট পশুচিকিৎসকের বিকল্প নয়, এটি শুধুমাত্র একটি তথ্যভিত্তিক সহায়ক।",

        # ---- Home ----
        "home_page_title": "SmartVet BD - AI ভিত্তিক পশু ও পাখির রোগ শনাক্তকরণ",
        "home_tagline": "AI-ভিত্তিক পশু ও পাখির রোগ শনাক্তকরণ সহায়ক",
        "home_cta_start": "ফ্রি শুরু করুন",
        "home_cta_dashboard": "ড্যাশবোর্ডে যান",
        "home_why": "কেন SmartVet BD?",
        "home_f1_title": "লক্ষণ থেকে রোগ শনাক্ত",
        "home_f1_desc": "রোগের নাম না জেনেও শুধু লক্ষণ বেছে সম্ভাব্য রোগ জানুন।",
        "home_f2_title": "প্রতিরোধের উপায়",
        "home_f2_desc": "প্রতিটি রোগের প্রাথমিক করণীয় ও প্রতিরোধ পদ্ধতি জানুন।",
        "home_f3_title": "সহজ বাংলা ভাষায়",
        "home_f3_desc": "প্রতিটি তথ্য সহজ, বোধগম্য বাংলা ভাষায় উপস্থাপিত।",
        "home_animals_title": "যেসব প্রাণী সাপোর্ট করে",

        # ---- Login / Register ----
        "login_page_title": "লগইন - SmartVet",
        "login_title": "লগইন করুন",
        "login_email_ph": "ইমেইল",
        "login_password_ph": "পাসওয়ার্ড",
        "login_btn": "লগইন",
        "login_no_account": "নতুন ব্যবহারকারী?",
        "login_register_link": "রেজিস্টার করুন",
        "login_error": "ইমেইল বা পাসওয়ার্ড ভুল হয়েছে।",
        "reg_page_title": "রেজিস্টার - SmartVet",
        "reg_title": "নিবন্ধন করুন",
        "reg_name_ph": "আপনার নাম",
        "reg_btn": "রেজিস্টার",
        "reg_have_account": "আগে থেকে অ্যাকাউন্ট আছে?",
        "reg_login_link": "লগইন করুন",
        "reg_error_empty": "সব ঘর পূরণ করুন।",
        "reg_error_exists": "এই ইমেইল দিয়ে আগেই অ্যাকাউন্ট আছে।",

        # ---- Dashboard ----
        "dash_page_title": "ড্যাশবোর্ড - SmartVet",
        "dash_header_sub": "AI-ভিত্তিক পশু রোগ শনাক্তকরণ ব্যবস্থা",
        "dash_welcome": "স্বাগতম",
        "dash_pick_animal": "কোন প্রাণীর রোগ পরীক্ষা করবেন?",
        "dash_detect": "রোগ শনাক্তকরণ",
        "dash_features": "সুবিধাসমূহ",
        "feat_vacc_title": "টিকা",
        "feat_vacc_desc": "টিকার সময়সূচি ট্র্যাক করুন।",
        "feat_history_title": "রোগের ইতিহাস",
        "feat_history_desc": "আগের পরীক্ষার ফলাফল দেখুন।",
        "feat_emergency_title": "জরুরি সহায়তা",
        "feat_emergency_desc": "দ্রুত প্রাথমিক চিকিৎসার নির্দেশনা।",
        "coming_soon": "শীঘ্রই আসছে",

        # ---- Animals ----
        "animal_Cow": "গরু",
        "animal_Goat": "ছাগল",
        "animal_Chicken": "মুরগি",
        "animal_Duck": "হাঁস",
        "animal_Dog": "কুকুর",
        "animal_Cat": "বিড়াল",
        "animal_Pigeon": "কবুতর",
        "animal_Fish": "মাছ",
        "animal_Rabbit": "খরগোশ",

        # ---- Disease detection page ----
        "detect_suffix": "রোগ শনাক্তকরণ",
        "select_symptoms": "লক্ষণ নির্বাচন করুন",
        "check_btn": "রোগ পরীক্ষা করুন",
        "detect_note": "এটি সম্ভাব্য মিল দেখায়, নিশ্চিত রোগ নির্ণয় নয়।",
        "sym_Fever": "জ্বর",
        "sym_Cough": "কাশি",
        "sym_Loss of Appetite": "খেতে চায় না",
        "sym_Diarrhea": "ডায়রিয়া",
        "sym_Skin Lesion": "চামড়ায় ঘা বা গুটি",
        "sym_Difficulty Breathing": "শ্বাসকষ্ট",
        "js_select_one": "অন্তত একটি লক্ষণ নির্বাচন করুন।",
        "js_no_disease_title": "কোনো রোগ পাওয়া যায়নি",
        "js_no_disease_msg": "নির্বাচিত লক্ষণের সাথে মিলে এমন কোনো রোগ পাওয়া যায়নি। দ্রুত পশুচিকিৎসকের পরামর্শ নিন।",
        "js_match": "মিল",
        "js_desc_label": "বিবরণ",
        "js_treatment_label": "প্রাথমিক করণীয়",
        "js_prevention_label": "প্রতিরোধ",
        "js_prev_1": "নিয়মিত টিকা দিন।",
        "js_prev_2": "খামার পরিষ্কার ও জীবাণুমুক্ত রাখুন।",
        "js_prev_3": "অসুস্থ প্রাণীকে দ্রুত আলাদা করুন।",
        "js_prev_4": "পরিষ্কার খাবার ও পানি দিন।",
        "js_disclaimer": "এটি সম্ভাব্য মিল, নিশ্চিত রোগ নির্ণয় নয়। অবস্থা গুরুতর হলে পশুচিকিৎসকের কাছে যান।",
        "js_server_error": "সার্ভারে সমস্যা হয়েছে। একটু পরে আবার চেষ্টা করুন।",

        # ---- AI chat ----
        "ai_page_title": "AI চ্যাট সহায়ক - SmartVet",
        "ai_title": "AI চ্যাট সহায়ক",
        "ai_disclaimer": "এই AI সহায়ক শুধু প্রাথমিক ধারণা দেয়, এটি পশুচিকিৎসকের বিকল্প নয়।",
        "ai_greeting": "আসসালামু আলাইকুম! আপনার প্রাণীর কী সমস্যা হচ্ছে, লক্ষণগুলো লিখে জানান।",
        "ai_placeholder": "যেমনঃ আমার গরুর জ্বর, খাচ্ছে না...",
        "js_typing": "লিখছে...",
        "js_ai_error": "একটা সমস্যা হয়েছে।",
        "js_conn_error": "সার্ভারের সাথে সংযোগ করা যাচ্ছে না।",
        "ai_server_error": "AI থেকে উত্তর পাওয়া যায়নি। একটু পরে আবার চেষ্টা করুন।",
        "ai_no_message": "কোনো মেসেজ পাওয়া যায়নি।",

        # ---- Emergency ----
        "em_page_title": "জরুরি সহায়তা - SmartVet",
        "em_title": "জরুরি প্রাথমিক সহায়তা",
        "em_disclaimer": "এগুলো শুধু জরুরি প্রাথমিক পদক্ষেপ। যত দ্রুত সম্ভব নিকটস্থ পশুচিকিৎসকের সাথে যোগাযোগ করুন।",
        "em_fever_title": "তীব্র জ্বর",
        "em_fever_text": "প্রাণীকে ছায়াযুক্ত, ঠান্ডা জায়গায় রাখুন। শরীরে ঠান্ডা পানি দিয়ে হালকা মুছে দিন। প্রচুর পরিষ্কার পানি দিন। জ্বর না কমলে দ্রুত ডাক্তার ডাকুন।",
        "em_breath_title": "শ্বাসকষ্ট",
        "em_breath_text": "প্রাণীকে খোলা, বাতাসযুক্ত জায়গায় নিয়ে যান। ভিড় ও ধোঁয়া থেকে দূরে রাখুন। জোর করে খাওয়াবেন না। দ্রুত ভেটেরিনারি সহায়তা নিন।",
        "em_bleed_title": "রক্তক্ষরণ",
        "em_bleed_text": "পরিষ্কার কাপড় দিয়ে ক্ষতস্থানে হালকা চাপ দিন। ক্ষতস্থান নাড়াবেন না। রক্ত বন্ধ না হলে বা বেশি হলে দ্রুত ডাক্তারের কাছে নিন।",
        "em_diarrhea_title": "তীব্র ডায়রিয়া",
        "em_diarrhea_text": "বিশুদ্ধ পানি ও ইলেক্ট্রোলাইট (ORS জাতীয়) দিন। খাবার সাময়িক বন্ধ রাখুন। ১২ ঘণ্টার বেশি স্থায়ী হলে ডাক্তার দেখান।",
        "em_poison_title": "বিষক্রিয়ার সন্দেহ",
        "em_poison_text": "আর কিছু খাওয়াবেন না। মুখের চারপাশ পরিষ্কার করুন। কী খেয়েছে বোঝার চেষ্টা করুন, সেই তথ্য ডাক্তারকে জানান। দ্রুত চিকিৎসা নিন।",
        "em_injury_title": "আঘাত বা দাঁড়াতে না পারা",
        "em_injury_text": "প্রাণীকে জোর করে নাড়াবেন না। আরামদায়ক, সমতল জায়গায় রাখুন। আক্রান্ত স্থানে চাপ দেবেন না। দ্রুত ভেটেরিনারি সহায়তা নিন।",

        # ---- History ----
        "hist_page_title": "রোগের ইতিহাস - SmartVet",
        "hist_title": "রোগ পরীক্ষার ইতিহাস",
        "hist_intro": "আপনার আগের রোগ পরীক্ষাগুলো এখানে দেখুন।",
        "hist_empty": "এখনো কোনো পরীক্ষা করা হয়নি।",
        "hist_empty_cta": "রোগ পরীক্ষা শুরু করুন",
        "hist_col_date": "তারিখ",
        "hist_col_animal": "প্রাণী",
        "hist_col_symptoms": "লক্ষণ",
        "hist_col_result": "সম্ভাব্য রোগ",
        "hist_no_match": "কোনো মিল পাওয়া যায়নি",

        # ---- Admin ----
        "admin_page_title": "অ্যাডমিন প্যানেল - SmartVet",
        "admin_title": "অ্যাডমিন প্যানেল",
        "admin_stat_users": "মোট ইউজার",
        "admin_stat_checks": "মোট রোগ পরীক্ষা",
        "admin_stat_diseases": "ডেটাবেসে রোগের সংখ্যা",
        "admin_users_list": "ইউজার তালিকা",
        "admin_col_id": "ID",
        "admin_col_name": "নাম",
        "admin_col_email": "ইমেইল",
        "admin_col_role": "ভূমিকা",
        "admin_col_action": "কাজ",
        "admin_make_admin": "অ্যাডমিন বানান",
        "admin_remove_admin": "অ্যাডমিন সরান",
        "admin_delete": "ডিলিট",
        "admin_you": "(আপনি)",
        "admin_confirm_delete": "এই ইউজারকে ডিলিট করবেন? এটা আর ফেরানো যাবে না।",
        "role_admin": "অ্যাডমিন",
        "role_user": "ইউজার",
        "admin_flash_bad_role": "ভুল ভূমিকা।",
        "admin_flash_self_role": "নিজের ভূমিকা নিজে বদলানো যাবে না।",
        "admin_flash_role_ok": "ভূমিকা সফলভাবে বদলানো হয়েছে।",
        "admin_flash_self_delete": "নিজের অ্যাকাউন্ট নিজে ডিলিট করা যাবে না।",
        "admin_flash_deleted": "ইউজার ডিলিট করা হয়েছে।",
        "forbidden_msg": "এই পেজে ঢোকার অনুমতি আপনার নেই।",
    },

    "en": {
        # ---- Navbar ----
        "nav_home": "Home",
        "nav_dashboard": "Dashboard",
        "nav_ai": "AI Assistant",
        "nav_admin": "Admin",
        "nav_history": "History",
        "nav_login": "Login",
        "nav_register": "Register",
        "nav_logout": "Logout",
        "lang_switch_label": "বাংলা",
        "lang_switch_title": "বাংলায় দেখুন",

        # ---- Common ----
        "back_dashboard": "Back to Dashboard",
        "site_footer": "© 2026 SmartVet BD — Right information, healthy animals, prosperous farms.",
        "site_disclaimer": "This site is not a substitute for a veterinarian. It is an information-based support tool only.",

        # ---- Home ----
        "home_page_title": "SmartVet BD - AI-Based Animal & Bird Disease Detection",
        "home_tagline": "Your AI assistant for animal & bird disease detection",
        "home_cta_start": "Get Started Free",
        "home_cta_dashboard": "Go to Dashboard",
        "home_why": "Why SmartVet BD?",
        "home_f1_title": "Find Diseases from Symptoms",
        "home_f1_desc": "Even without knowing the disease name, pick the symptoms and see possible diseases.",
        "home_f2_title": "Prevention Tips",
        "home_f2_desc": "Learn the first steps and prevention methods for every disease.",
        "home_f3_title": "In Your Own Language",
        "home_f3_desc": "All information is written in simple Bangla, and English is one click away.",
        "home_animals_title": "Supported Animals",

        # ---- Login / Register ----
        "login_page_title": "Login - SmartVet",
        "login_title": "Login to your account",
        "login_email_ph": "Email",
        "login_password_ph": "Password",
        "login_btn": "Login",
        "login_no_account": "New here?",
        "login_register_link": "Create an account",
        "login_error": "Incorrect email or password.",
        "reg_page_title": "Register - SmartVet",
        "reg_title": "Create Account",
        "reg_name_ph": "Your name",
        "reg_btn": "Register",
        "reg_have_account": "Already have an account?",
        "reg_login_link": "Login",
        "reg_error_empty": "Please fill in all fields.",
        "reg_error_exists": "An account with this email already exists.",

        # ---- Dashboard ----
        "dash_page_title": "Dashboard - SmartVet",
        "dash_header_sub": "AI-Based Animal Disease Detection System",
        "dash_welcome": "Welcome",
        "dash_pick_animal": "Which animal would you like to check?",
        "dash_detect": "Disease Detection",
        "dash_features": "Features",
        "feat_vacc_title": "Vaccination",
        "feat_vacc_desc": "Track vaccination schedule.",
        "feat_history_title": "Disease History",
        "feat_history_desc": "View previous diagnoses.",
        "feat_emergency_title": "Emergency Help",
        "feat_emergency_desc": "Quick first-aid guidelines.",
        "coming_soon": "Coming soon",

        # ---- Animals ----
        "animal_Cow": "Cow",
        "animal_Goat": "Goat",
        "animal_Chicken": "Chicken",
        "animal_Duck": "Duck",
        "animal_Dog": "Dog",
        "animal_Cat": "Cat",
        "animal_Pigeon": "Pigeon",
        "animal_Fish": "Fish",
        "animal_Rabbit": "Rabbit",

        # ---- Disease detection page ----
        "detect_suffix": "Disease Detection",
        "select_symptoms": "Select Symptoms",
        "check_btn": "Check Disease",
        "detect_note": "Results show possible matches, not a confirmed diagnosis.",
        "sym_Fever": "Fever",
        "sym_Cough": "Cough",
        "sym_Loss of Appetite": "Loss of Appetite",
        "sym_Diarrhea": "Diarrhea",
        "sym_Skin Lesion": "Skin Lesion",
        "sym_Difficulty Breathing": "Difficulty Breathing",
        "js_select_one": "Please select at least one symptom.",
        "js_no_disease_title": "No Disease Found",
        "js_no_disease_msg": "No disease matches the selected symptoms. Please consult a veterinarian.",
        "js_match": "Match",
        "js_desc_label": "Description",
        "js_treatment_label": "First Steps",
        "js_prevention_label": "Prevention",
        "js_prev_1": "Vaccinate animals regularly.",
        "js_prev_2": "Keep the farm clean and hygienic.",
        "js_prev_3": "Isolate sick animals immediately.",
        "js_prev_4": "Provide clean food and water.",
        "js_disclaimer": "This is a possible match, not a confirmed diagnosis. If the condition is serious, see a veterinarian.",
        "js_server_error": "Server error. Please try again shortly.",

        # ---- AI chat ----
        "ai_page_title": "AI Chat Assistant - SmartVet",
        "ai_title": "AI Chat Assistant",
        "ai_disclaimer": "This AI assistant gives only preliminary guidance. It is not a substitute for a veterinarian.",
        "ai_greeting": "Hello! Tell us what is wrong with your animal and describe the symptoms.",
        "ai_placeholder": "e.g. My cow has a fever and is not eating...",
        "js_typing": "Typing...",
        "js_ai_error": "Something went wrong.",
        "js_conn_error": "Cannot connect to the server.",
        "ai_server_error": "Could not get a response from the AI. Please try again shortly.",
        "ai_no_message": "No message received.",

        # ---- Emergency ----
        "em_page_title": "Emergency Help - SmartVet",
        "em_title": "Emergency First Aid",
        "em_disclaimer": "These are only emergency first steps. Contact the nearest veterinarian as soon as possible.",
        "em_fever_title": "High Fever",
        "em_fever_text": "Keep the animal in a shaded, cool place. Gently wipe the body with cool water. Provide plenty of clean water. If the fever does not come down, call a vet quickly.",
        "em_breath_title": "Difficulty Breathing",
        "em_breath_text": "Move the animal to an open, well-ventilated place. Keep it away from crowds and smoke. Do not force-feed. Get veterinary help quickly.",
        "em_bleed_title": "Bleeding",
        "em_bleed_text": "Apply gentle pressure to the wound with a clean cloth. Do not disturb the wound. If bleeding does not stop or is heavy, take the animal to a vet quickly.",
        "em_diarrhea_title": "Severe Diarrhea",
        "em_diarrhea_text": "Give clean water and electrolytes (such as ORS). Hold food for a short time. If it lasts more than 12 hours, see a vet.",
        "em_poison_title": "Suspected Poisoning",
        "em_poison_text": "Do not give anything else to eat or drink. Clean around the mouth. Try to find out what it ate and tell the vet. Get treatment quickly.",
        "em_injury_title": "Injury or Unable to Stand",
        "em_injury_text": "Do not force the animal to move. Keep it on a comfortable, flat surface. Do not press on the injured area. Get veterinary help quickly.",

        # ---- History ----
        "hist_page_title": "Disease History - SmartVet",
        "hist_title": "Disease Check History",
        "hist_intro": "See your previous disease checks here.",
        "hist_empty": "You have not made any checks yet.",
        "hist_empty_cta": "Start a disease check",
        "hist_col_date": "Date",
        "hist_col_animal": "Animal",
        "hist_col_symptoms": "Symptoms",
        "hist_col_result": "Possible Disease",
        "hist_no_match": "No match found",

        # ---- Admin ----
        "admin_page_title": "Admin Panel - SmartVet",
        "admin_title": "Admin Panel",
        "admin_stat_users": "Total Users",
        "admin_stat_checks": "Total Disease Checks",
        "admin_stat_diseases": "Diseases in Database",
        "admin_users_list": "User List",
        "admin_col_id": "ID",
        "admin_col_name": "Name",
        "admin_col_email": "Email",
        "admin_col_role": "Role",
        "admin_col_action": "Actions",
        "admin_make_admin": "Make Admin",
        "admin_remove_admin": "Remove Admin",
        "admin_delete": "Delete",
        "admin_you": "(You)",
        "admin_confirm_delete": "Delete this user? This cannot be undone.",
        "role_admin": "Admin",
        "role_user": "User",
        "admin_flash_bad_role": "Invalid role.",
        "admin_flash_self_role": "You cannot change your own role.",
        "admin_flash_role_ok": "Role updated successfully.",
        "admin_flash_self_delete": "You cannot delete your own account.",
        "admin_flash_deleted": "User deleted.",
        "forbidden_msg": "You do not have permission to access this page.",
    },
}


AI_INSTRUCTIONS = {
    "bn": (
        "তুমি SmartVet BD-এর একজন সহায়ক AI অ্যাসিস্ট্যান্ট। "
        "তুমি বাংলাদেশের কৃষকদের গরু, ছাগল, মুরগি, হাঁস, কুকুর, বিড়াল, কবুতর, মাছ ও খরগোশের "
        "স্বাস্থ্য সমস্যা বুঝতে সাহায্য করো। "
        "কৃষক তার প্রশ্ন বাংলা হরফে, বাংলিশ (যেমন 'amar gorur jor hoise'), অথবা ইংরেজিতে লিখতে পারে — "
        "তুমি সবক্ষেত্রেই ইনপুট বুঝবে। "
        "কিন্তু তোমার উত্তর সবসময় শুধুমাত্র বাংলা হরফে দেবে, ইংরেজি অক্ষরে (বাংলিশ) কখনো উত্তর দেবে না। "
        "সবসময় সহজ, সংক্ষিপ্ত বাংলা ভাষায় উত্তর দাও। "
        "কৃষক লক্ষণ বললে, সম্ভাব্য রোগ ও প্রাথমিক করণীয় বলো। "
        "কিন্তু প্রতিটি উত্তরের শেষে অবশ্যই স্পষ্টভাবে বলো যে এটি চূড়ান্ত ডায়াগনোসিস নয় এবং "
        "গুরুতর অবস্থায় দ্রুত পশুচিকিৎসকের পরামর্শ নেওয়া জরুরি। "
        "তুমি কখনো নির্দিষ্ট ওষুধের ডোজ বলবে না।"
    ),
    "en": (
        "You are a helpful AI assistant for SmartVet BD. "
        "You help farmers in Bangladesh understand health problems in cows, goats, chickens, ducks, "
        "dogs, cats, pigeons, fish and rabbits. "
        "The user may write in Bengali script, in Banglish (Bengali written in English letters, "
        "for example 'amar gorur jor hoise'), or in English. Understand all of them. "
        "Always reply only in simple, short English. "
        "When the user describes symptoms, mention possible diseases and safe first steps. "
        "At the end of every reply, clearly state that this is not a final diagnosis and that in "
        "serious cases a veterinarian should be consulted urgently. "
        "Never give specific medicine doses."
    ),
}


def get_text(lang, key, default=None):
    """Return the text for key in the given language (falls back to English, then the key)."""
    table = TRANSLATIONS.get(lang) or TRANSLATIONS[DEFAULT_LANG]
    if key in table:
        return table[key]
    if key in TRANSLATIONS["en"]:
        return TRANSLATIONS["en"][key]
    return default if default is not None else key


def js_strings(lang):
    """All texts whose key starts with js_ (these are handed to the browser's JavaScript)."""
    result = {k: v for k, v in TRANSLATIONS["en"].items() if k.startswith("js_")}
    result.update({k: v for k, v in TRANSLATIONS.get(lang, {}).items() if k.startswith("js_")})
    return result


if __name__ == "__main__":
    bn_keys = set(TRANSLATIONS["bn"])
    en_keys = set(TRANSLATIONS["en"])
    print("bn:", len(bn_keys), "en:", len(en_keys))
    print("Missing in en:", sorted(bn_keys - en_keys) or "none")
    print("Missing in bn:", sorted(en_keys - bn_keys) or "none")
